//
//  RoomViewController.swift
//  DabangClone
//
//  Created by 정의석 on 2020/04/05.
//  Copyright © 2020 pandaman. All rights reserved.
//

import UIKit
import Kingfisher

class MainRoomViewController: UIViewController {
  let roomData = findRoomDataFromRoomID(rooms, roomID: 1)
  
  //MARK: - Property
  let scrollView = UIScrollView().then {
    $0.backgroundColor = .gray
    $0.alwaysBounceVertical = true
  }
  
  let contentsView = UIView().then {
    $0.backgroundColor = .cyan
  }
  
  let imageScrollView = UIScrollView().then {
    $0.isPagingEnabled = true
    $0.backgroundColor = .orange
  }
  let grayBox = UIView().then {
    $0.backgroundColor = .gray
  }
  
  //MARK: - Life Cycle
  override func viewDidLoad() {
    super.viewDidLoad()
    view.backgroundColor = .white
    
    setupUI()
    setupImages()
  }
  
  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    
  }
  
  //MARK: - SetupUI & SetupConstraints
  
  private func setupUI() {
    
    scrollView.frame = view.frame
    imageScrollView.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height * 0.3)
    
    view.addSubviews([scrollView])
    
    scrollView.addSubview(contentsView)
    
    contentsView.addSubviews([grayBox, imageScrollView])
    
    setupConstraints()
  }
  
  private func setupConstraints() {
    scrollView.snp.makeConstraints {
      $0.edges.equalToSuperview()
    }
    scrollView.contentSize.height = self.view.frame.height * 2
    
    contentsView.snp.makeConstraints {
      $0.top.trailing.leading.equalTo(scrollView)
      $0.height.equalTo(1000)
    }
    
    imageScrollView.snp.makeConstraints {
      $0.leading.top.trailing.equalTo(view)
      $0.height.equalTo(view).multipliedBy(0.3)
    }
    
    grayBox.snp.makeConstraints {
      $0.width.equalTo(view)
      $0.top.equalTo(imageScrollView.snp.bottom).offset(200)
      $0.leading.trailing.equalToSuperview()
//      $0.center.equalToSuperview()
      $0.height.equalTo(500)
    }
    
    
  }
  
  //MARK: - Actions
  private func setupImages() {
    let images = roomData.images
    for i in 0..<images.count {
      let imageView = UIImageView()
      let url = URL(string: images[i].image)
      imageView.kf.setImage(with: url)
      imageView.contentMode = .scaleAspectFill
      let xPosition = self.view.frame.width * CGFloat(i)
      imageView.frame = CGRect(x: xPosition, y: 0, width: self.view.frame.width, height: self.imageScrollView.frame.height)
      
      imageScrollView.contentSize.width = self.view.frame.width * CGFloat(1+i)
      
      imageScrollView.addSubview(imageView)
    }
    
  }
  
}


