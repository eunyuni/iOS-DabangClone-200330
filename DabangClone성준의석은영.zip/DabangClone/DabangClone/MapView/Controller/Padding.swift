//
//  Padding.swift
//  DabangClone
//
//  Created by 은영김 on 2020/04/03.
//  Copyright © 2020 pandaman. All rights reserved.
//

import UIKit

struct Padding {
  static let topBottom: CGFloat = 32
  static let spacing: CGFloat = 6
}

