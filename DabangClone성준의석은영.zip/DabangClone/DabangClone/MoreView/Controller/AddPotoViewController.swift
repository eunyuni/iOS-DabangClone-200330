//
//  AddPotoViewController.swift
//  DabangClone
//
//  Created by 황정덕 on 2020/03/27.
//  Copyright © 2020 pandaman. All rights reserved.
//

import UIKit

class AddPotoViewController: UIViewController {

  override func viewDidLoad() {
    super.viewDidLoad()
  }
}
